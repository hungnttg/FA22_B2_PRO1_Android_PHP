package edu.fpt.lenovo.shoponline.activity;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import lenovo.shoponline.R;

public class HelloActivity extends AppCompatActivity {
    @Override
    public void onCreate( Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hello);
        
    }
}
