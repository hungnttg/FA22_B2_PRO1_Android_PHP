package edu.fpt.lenovo.shoponline.activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import java.text.DecimalFormat;

import edu.fpt.lenovo.shoponline.adapter.GiohangAdapter;
import edu.fpt.lenovo.shoponline.ultil.CheckConnetion;
import lenovo.shoponline.R;

public class GiohangActivity extends AppCompatActivity {
    Toolbar toolbar;
    ListView listView;
    TextView txtThongbao;
    static TextView txtTongTien;//tong tien luon duoc cong don,khong bi thay doi khi chuyen activity
    Button btnthanhtoan,btntieptucmuahang;
    GiohangAdapter giohangAdapter;
    void Anhxa()
    {
        listView = findViewById(R.id.listviewgiohang);
        txtThongbao = findViewById(R.id.textviewthongbao);
        txtTongTien = findViewById(R.id.textviewtongtien);
        btnthanhtoan = findViewById(R.id.buttonthanhtoangiohang);
        btntieptucmuahang = findViewById(R.id.buttontieptucmuahang);
        toolbar = findViewById(R.id.toolbargiohang);
        giohangAdapter = new GiohangAdapter(GiohangActivity.this,MainActivity.manggiohang);
        listView.setAdapter(giohangAdapter);


    }
    void ActionToolBar()
    {
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        toolbar.setNavigationOnClickListener(new View.OnClickListener() {//xu ly su kien khi click toolbar
            @Override
            public void onClick(View view) {
                finish();
            }
        });
    }
    void CheckData()
    {
        if(MainActivity.manggiohang.size()<=0)
        {
            giohangAdapter.notifyDataSetChanged();
            txtThongbao.setVisibility(View.VISIBLE);
            listView.setVisibility(View.INVISIBLE);
        }
        else
        {
            giohangAdapter.notifyDataSetChanged();
            txtThongbao.setVisibility(View.INVISIBLE);
            listView.setVisibility(View.VISIBLE);
        }
    }
    void ClickItemListview()
    {
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                if(MainActivity.manggiohang.size()<1)
                {
                    txtThongbao.setVisibility(View.VISIBLE);
                }
                else
                {
                    MainActivity.manggiohang.remove(i);//xoa san pham khoi gio hang
                    giohangAdapter.notifyDataSetChanged();
                    //cap nhat lai tong tien
                    UpdateTongTien();
                    if(MainActivity.manggiohang.size() <1)
                    {
                        txtThongbao.setVisibility(View.VISIBLE);
                    }
                    else
                    {
                        txtThongbao.setVisibility(View.INVISIBLE);
                        giohangAdapter.notifyDataSetChanged();
                        UpdateTongTien();
                    }
                }
            }
        });

//        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
//            @Override
//            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
//                AlertDialog.Builder builder = new AlertDialog.Builder(GiohangActivity.this);
//                builder.setTitle("Xac nhan xoa san pham");
//                builder.setMessage("Ban co muon xoa san pham nay khong?");
//                builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
//                    @Override
//                    public void onClick(DialogInterface dialogInterface, int i) {
//                      if(MainActivity.manggiohang.size()<1)
//                {
//                    txtThongbao.setVisibility(View.VISIBLE);
//                }
//                else
//                {
//                    MainActivity.manggiohang.remove(i);//xoa san pham khoi gio hang
//                    giohangAdapter.notifyDataSetChanged();
//                    //cap nhat lai tong tien
//                    UpdateTongTien();
//                    if(MainActivity.manggiohang.size() <1)
//                    {
//                        txtThongbao.setVisibility(View.VISIBLE);
//                    }
//                    else
//                    {
//                        txtThongbao.setVisibility(View.INVISIBLE);
//                        giohangAdapter.notifyDataSetChanged();
//                        UpdateTongTien();
//                    }
//                }
//                    }
//                });
//                builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
//                    @Override
//                    public void onClick(DialogInterface dialogInterface, int i) {
//                        giohangAdapter.isEmpty();
//                        UpdateTongTien();
//                    }
//                });
//                builder.show();
//            }
//        });

    }


    void ClickButton()
    {
        btntieptucmuahang.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(),MainActivity.class);
                startActivity(intent);
            }
        });
        btnthanhtoan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(MainActivity.manggiohang.size() >0)
                {
                    //Intent intent = new Intent(getApplicationContext(),ThongTinKhachHang.class);
                    //startActivity(intent);
                }
                else
                {
                    CheckConnetion.ShowToastLong(getApplicationContext(),"Gio hang rong");
                }
            }
        });
    }
    public static void UpdateTongTien()
    {
        long tongtien=0;
        for(int i = 0;i<MainActivity.manggiohang.size();i++)
        {
            tongtien += MainActivity.manggiohang.get(i).getGiasp();
        }
        DecimalFormat decimalFormat = new DecimalFormat("###,###,###");
        txtTongTien.setText(decimalFormat.format(tongtien)+" VND");
    }
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_giohang);
        Anhxa();
        ActionToolBar();
        CheckData();//kiem tra gio hang
        ClickItemListview();
        ClickButton();
        UpdateTongTien();
    }
}
